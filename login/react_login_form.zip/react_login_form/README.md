# "React Login Form with Authentication, Axios, and Accessibility"

✅ [Check out my YouTube Channel with all of my tutorials](https://www.youtube.com/DaveGrayTeachesCode).

**Description:**

This repository shares the code applied during the [YouTube Tutorial](https://youtu.be/X3qyxo_UTR4). 

Build the backend REST API that I test this registration form with in my [7 hour Node JS for Beginners course](https://youtu.be/f2EqECiTBL8) on my channel.

Just starting with React? I have a [9 hour React course tutorial video](https://youtu.be/RVFAyFWO4go) on my channel.  

I suggest completing my [8 hour JavaScript course tutorial video](https://youtu.be/EfAl9bwzVZk) before attempting React if you are new to Javascript.

### Academic Honesty

**DO NOT COPY FOR AN ASSIGNMENT** - Avoid plagiargism and adhere to the spirit of this [Academic Honesty Policy](https://www.freecodecamp.org/news/academic-honesty-policy/).
