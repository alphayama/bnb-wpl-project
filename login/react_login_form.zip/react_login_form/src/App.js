import Register from './Register';
import Login from './Login';
import { useState } from 'react';

function App() {
  const [showLogin,setShowLogin] = useState(true);

  return (
    <main className="App">
      {
        (showLogin)?(
          <div>
            <Login 
              showLogin={showLogin}
              setShowLogin={setShowLogin}/>
            <button onClick={()=>setShowLogin(false)}>Register</button>
          </div>
          ):(
            <div>
              <Register 
                showLogin={showLogin}
                setShowLogin={setShowLogin}/>
              <button onClick={()=>setShowLogin(true)}>Sign In</button>
            </div>
          
          )
      }
      
    </main>
  );
}

export default App;