const User = require('../model/User');
const bcrypt = require('bcrypt');

const handleNewUser = async (req, res) => {
    const { fname, lname, email, pwd, host } = req.body;
    if (!fname|| !lname || !email || !pwd) return res.status(400).json({ 'message': 'all informations are required.' });
    let host2 = host
    if (host!=true) {
        host2=false;
    }
    // check for duplicate usernames in the db
    const duplicate = await User.findOne({ email : email }).exec();
    if (duplicate) return res.sendStatus(409); //Conflict 

    try {
        //encrypt the password
        const hashedPwd = await bcrypt.hash(pwd, 10);

        //create and store the new user
        const result = await User.create({
            "fname": fname,
            "lname": lname,
            "email": email,
            "password": hashedPwd,
            "is_host": host2
        });

        console.log(result);

        res.status(201).json({ 'success': `New user ${email} created!` });
    } catch (err) {
        res.status(500).json({ 'message': err.message });
    }
}

module.exports = { handleNewUser };